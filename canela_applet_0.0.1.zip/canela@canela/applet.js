const Applet = imports.ui.applet;
const PopupMenu = imports.ui.popupMenu;
const Settings = imports.ui.settings;
const St = imports.gi.St;
const GLib = imports.gi.GLib;
const Gio = imports.gi.Gio;
const Lang = imports.lang;
const Mainloop = imports.mainloop;

const UUID = "canela@canela";
const APPLET_DIR = imports.ui.appletManager.appletMeta[UUID].path;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function clamp(val, min, max) {
    return Math.max(min, Math.min(max, val));
}

// ---------------------------------------------------------------------------
// Main Applet
// ---------------------------------------------------------------------------

function CanelaApplet(metadata, orientation, panelHeight, instanceId) {
    this._init(metadata, orientation, panelHeight, instanceId);
}

CanelaApplet.prototype = {
    __proto__: Applet.IconApplet.prototype,

    _init: function(metadata, orientation, panelHeight, instanceId) {
        Applet.IconApplet.prototype._init.call(this, orientation, panelHeight, instanceId);

        this.set_applet_icon_symbolic_name("camera-web");
        this.set_applet_tooltip("Canela — Cam & Mic settings");

        // Settings bindings
        this.settings = new Settings.AppletSettings(this, UUID, instanceId);
        this._bindSettings();

        // State
        this._source = this.settings.getValue("active-source") || "cam";
        this._backendProc = null;
        this._sessionType = "x11";

        // Build popup menu
        this.menuManager = new PopupMenu.PopupMenuManager(this);
        this.menu = new Applet.AppletPopupMenu(this, orientation);
        this.menuManager.addMenu(this.menu);
        this._buildMenu();

        // Start backend
        this._startBackend();
    },

    // -----------------------------------------------------------------------
    // Settings
    // -----------------------------------------------------------------------

    _bindSettings: function() {
        let keys = [
            "active-source",
            "cam-brightness", "cam-contrast", "cam-blur", "cam-mode", "cam-muted",
            "mic-range", "mic-gain", "mic-reverb", "mic-noise-reduction", "mic-muted"
        ];
        keys.forEach(k => {
            this.settings.bindProperty(
                Settings.BindingDirection.BIDIRECTIONAL,
                k, "_s_" + k.replace(/-/g, "_"),
                this._onSettingChanged.bind(this), null
            );
        });
    },

    _onSettingChanged: function() {
        this._syncBackend();
        this._refreshMenu();
    },

    // -----------------------------------------------------------------------
    // Backend process (backend.py)
    // -----------------------------------------------------------------------

    _startBackend: function() {
        try {
            let [ok, pid, stdin, stdout] = GLib.spawn_async_with_pipes(
                APPLET_DIR,
                ["python3", APPLET_DIR + "/backend.py"],
                null,
                GLib.SpawnFlags.DO_NOT_REAP_CHILD,
                null
            );

            this._backendStdin  = new Gio.DataOutputStream({
                base_stream: new Gio.UnixOutputStream({ fd: stdin, close_fd: true })
            });
            this._backendStdout = new Gio.DataInputStream({
                base_stream: new Gio.UnixInputStream({ fd: stdout, close_fd: true })
            });
            this._backendPid = pid;

            // Read first line (ready message)
            this._readBackendLine();

        } catch(e) {
            global.logError("[Canela] Failed to start backend: " + e.message);
        }
    },

    _readBackendLine: function() {
        this._backendStdout.read_line_async(
            GLib.PRIORITY_DEFAULT, null,
            (stream, result) => {
                try {
                    let [line] = stream.read_line_finish_utf8(result);
                    if (line) {
                        let msg = JSON.parse(line);
                        if (msg.session) {
                            this._sessionType = msg.session;
                            this.set_applet_tooltip(
                                "Canela — Cam & Mic settings\nSession: " + msg.session.toUpperCase()
                            );
                        }
                    }
                } catch(e) {}
            }
        );
    },

    _sendBackend: function(obj) {
        if (!this._backendStdin) return;
        try {
            this._backendStdin.put_string(JSON.stringify(obj) + "\n", null);
        } catch(e) {
            global.logError("[Canela] Backend write error: " + e.message);
        }
    },

    _syncBackend: function() {
        let s = this.settings;
        if (this._s_cam_muted) {
            this._sendBackend({ action: "cam_stop" });
        } else {
            this._sendBackend({
                action: "cam_update",
                brightness: s.getValue("cam-brightness"),
                contrast:   s.getValue("cam-contrast"),
                blur:       s.getValue("cam-blur")
            });
        }
        if (this._s_mic_muted) {
            this._sendBackend({ action: "mic_stop" });
        } else {
            this._sendBackend({
                action: "mic_update",
                gain:            s.getValue("mic-gain"),
                reverb:          s.getValue("mic-reverb"),
                noise_reduction: s.getValue("mic-noise-reduction"),
                mic_range:       s.getValue("mic-range")
            });
        }
    },

    _stopBackend: function() {
        if (this._backendStdin) {
            this._sendBackend({ action: "quit" });
            this._backendStdin = null;
        }
    },

    // -----------------------------------------------------------------------
    // Menu
    // -----------------------------------------------------------------------

    _buildMenu: function() {
        this.menu.removeAll();

        // Source switcher: Camera | Microphone
        let switcherItem = new PopupMenu.PopupBaseMenuItem({ reactive: false });
        let switcherBox = new St.BoxLayout({ style_class: "canela-switcher" });

        this._camBtn = new St.Button({
            label: "Camera",
            style_class: "canela-sw-btn" + (this._source === "cam" ? " active" : ""),
            reactive: true
        });
        this._micBtn = new St.Button({
            label: "Microphone",
            style_class: "canela-sw-btn" + (this._source === "mic" ? " active" : ""),
            reactive: true
        });
        this._camBtn.connect("clicked", () => this._setSource("cam"));
        this._micBtn.connect("clicked", () => this._setSource("mic"));

        switcherBox.add(this._camBtn, { expand: true });
        switcherBox.add(this._micBtn, { expand: true });
        switcherItem.addActor(switcherBox, { expand: true });
        this.menu.addMenuItem(switcherItem);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        // Sliders panel (cam or mic depending on source)
        if (this._source === "cam") {
            this._addCamPanel();
        } else {
            this._addMicPanel();
        }

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        // Mute button
        this._addMuteButton();

        // Session info
        let infoItem = new PopupMenu.PopupBaseMenuItem({ reactive: false });
        infoItem.addActor(new St.Label({
            text: "Session: " + this._sessionType.toUpperCase() + "  |  Canela v0.0.1",
            style: "font-size: 10px; color: #888;"
        }));
        this.menu.addMenuItem(infoItem);
    },

    _refreshMenu: function() {
        this._buildMenu();
    },

    _setSource: function(src) {
        this._source = src;
        this.settings.setValue("active-source", src);
        this._buildMenu();
    },

    // -----------------------------------------------------------------------
    // Camera panel
    // -----------------------------------------------------------------------

    _addCamPanel: function() {
        let s = this.settings;

        this._addSlider("BRILLO",            "cam-brightness", 0, 100);
        this._addSlider("CONTRASTE",          "cam-contrast",   0, 100);
        this._addSlider("DESENFOQUE DE FONDO","cam-blur",       0, 100);

        // Portrait / Landscape toggle
        let modeItem = new PopupMenu.PopupBaseMenuItem({ reactive: false });
        let modeBox  = new St.BoxLayout();

        let btnPortrait  = new St.Button({ label: "Portrait",  style_class: "canela-mode-btn" + (s.getValue("cam-mode") === "portrait"  ? " active" : "") });
        let btnLandscape = new St.Button({ label: "Landscape", style_class: "canela-mode-btn" + (s.getValue("cam-mode") === "landscape" ? " active" : "") });

        btnPortrait.connect("clicked",  () => { s.setValue("cam-mode", "portrait");  this._buildMenu(); });
        btnLandscape.connect("clicked", () => { s.setValue("cam-mode", "landscape"); this._buildMenu(); });

        modeBox.add(btnPortrait,  { expand: true });
        modeBox.add(btnLandscape, { expand: true });
        modeItem.addActor(modeBox, { expand: true });
        this.menu.addMenuItem(modeItem);
    },

    // -----------------------------------------------------------------------
    // Mic panel
    // -----------------------------------------------------------------------

    _addMicPanel: function() {
        this._addSlider("ALCANCE",           "mic-range",          0, 100);
        this._addSlider("GANANCIA",          "mic-gain",           0, 100);
        this._addSlider("REVERBERACIÓN",     "mic-reverb",         0, 100);
        this._addSlider("REDUCCIÓN DE RUIDO","mic-noise-reduction",0, 100);
    },

    // -----------------------------------------------------------------------
    // Shared slider builder
    // -----------------------------------------------------------------------

    _addSlider: function(label, key, min, max) {
        let item = new PopupMenu.PopupBaseMenuItem({ reactive: false });
        let box  = new St.BoxLayout({ vertical: true, style: "padding: 2px 0;" });

        let row  = new St.BoxLayout();
        let lbl  = new St.Label({ text: label, style: "font-size:11px; font-weight:bold;" });
        let val  = new St.Label({
            text: this.settings.getValue(key) + "%",
            style: "font-size:11px; min-width:36px; text-align:right;"
        });
        row.add(lbl, { expand: true });
        row.add(val);

        let slider = new PopupMenu.PopupSliderMenuItem(
            clamp(this.settings.getValue(key), min, max) / max
        );
        slider.connect("value-changed", (s) => {
            let v = Math.round(s.value * max);
            this.settings.setValue(key, v);
            val.set_text(v + "%");
            this._syncBackend();
        });

        box.add(row);
        box.add(slider.actor, { expand: true });
        item.addActor(box, { expand: true });
        this.menu.addMenuItem(item);
    },

    // -----------------------------------------------------------------------
    // Mute button
    // -----------------------------------------------------------------------

    _addMuteButton: function() {
        let key    = this._source === "cam" ? "cam-muted" : "mic-muted";
        let muted  = this.settings.getValue(key);
        let label  = this._source === "cam"
            ? (muted ? "Activar cámara"      : "Desactivar cámara")
            : (muted ? "Activar micrófono"   : "Desactivar micrófono");

        let muteItem = new PopupMenu.PopupBaseMenuItem({ reactive: false });
        let muteBtn  = new St.Button({
            label: label,
            style_class: "canela-mute-btn " + (muted ? "muted" : "active"),
            reactive: true
        });
        muteBtn.connect("clicked", () => {
            this.settings.setValue(key, !muted);
            this._syncBackend();
            this._buildMenu();
        });
        muteItem.addActor(muteBtn, { expand: true });
        this.menu.addMenuItem(muteItem);
    },

    // -----------------------------------------------------------------------
    // Applet lifecycle
    // -----------------------------------------------------------------------

    on_applet_clicked: function(event) {
        this.menu.toggle();
    },

    on_applet_removed_from_panel: function() {
        this._stopBackend();
        this.settings.finalize();
    }
};

function main(metadata, orientation, panelHeight, instanceId) {
    return new CanelaApplet(metadata, orientation, panelHeight, instanceId);
}
