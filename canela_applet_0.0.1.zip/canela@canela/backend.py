#!/usr/bin/env python3
"""
Canela - backend.py
Handles camera and microphone control.
Detects X11 vs Wayland and selects the appropriate GStreamer source.
"""

import os
import sys
import json
import signal
import gi

gi.require_version("Gst", "1.0")
from gi.repository import Gst, GLib

Gst.init(None)


# ---------------------------------------------------------------------------
# Session detection
# ---------------------------------------------------------------------------

def detect_session():
    """
    Returns 'wayland' or 'x11'.
    Checks XDG_SESSION_TYPE first, then falls back to WAYLAND_DISPLAY.
    """
    session = os.environ.get("XDG_SESSION_TYPE", "").lower()
    if session == "wayland":
        return "wayland"
    if os.environ.get("WAYLAND_DISPLAY"):
        return "wayland"
    return "x11"


SESSION = detect_session()


def get_camera_src():
    """
    Returns the GStreamer source element for the camera
    depending on the current display session.
    """
    if SESSION == "wayland":
        # PipeWire portal - works on Wayland without xdg-portal permissions issues
        return "pipewiresrc"
    else:
        # Direct V4L2 access - standard on X11
        return "v4l2src"


def get_mic_src():
    """
    PipeWire handles both X11 and Wayland for audio.
    PulseAudio compat layer is available via pulsesrc as fallback.
    """
    if SESSION == "wayland":
        return "pipewiresrc"
    else:
        # pulsesrc works on both but v4l2 is more direct on X11
        return "pulsesrc"


# ---------------------------------------------------------------------------
# Camera pipeline
# ---------------------------------------------------------------------------

class CameraBackend:
    def __init__(self):
        self.pipeline = None
        self.running = False

    def build_pipeline(self, brightness=72, contrast=45, blur=20):
        src = get_camera_src()

        # Map 0-100 slider values to GStreamer ranges
        # gamma: 0.01 - 10.0  (1.0 = neutral)
        gamma_val = 0.01 + (brightness / 100.0) * 9.99

        # videobalance contrast: -2.0 to 2.0 (0.0 = neutral)
        contrast_val = -2.0 + (contrast / 100.0) * 4.0

        # blur radius: 0 - 15 pixels
        blur_radius = int((blur / 100.0) * 15)

        pipeline_str = (
            f"{src} ! videoconvert ! "
            f"gamma gamma={gamma_val:.2f} ! "
            f"videobalance contrast={contrast_val:.2f} ! "
        )

        if blur_radius > 0:
            pipeline_str += f"gaussianblur sigma={blur_radius} ! "

        # Output to a virtual v4l2 loopback device if available (/dev/video2)
        # Falls back to autovideosink for preview only
        if os.path.exists("/dev/video2"):
            pipeline_str += "video/x-raw,format=YUY2 ! v4l2sink device=/dev/video2"
        else:
            pipeline_str += "autovideosink"

        return pipeline_str

    def start(self, brightness=72, contrast=45, blur=20):
        self.stop()
        pipeline_str = self.build_pipeline(brightness, contrast, blur)
        try:
            self.pipeline = Gst.parse_launch(pipeline_str)
            self.pipeline.set_state(Gst.State.PLAYING)
            self.running = True
        except Exception as e:
            print(f"[Canela] Camera pipeline error: {e}", file=sys.stderr)

    def stop(self):
        if self.pipeline:
            self.pipeline.set_state(Gst.State.NULL)
            self.pipeline = None
        self.running = False

    def update(self, brightness=72, contrast=45, blur=20):
        """Restart pipeline with new values."""
        if self.running:
            self.start(brightness, contrast, blur)


# ---------------------------------------------------------------------------
# Microphone pipeline
# ---------------------------------------------------------------------------

class MicBackend:
    def __init__(self):
        self.pipeline = None
        self.running = False

    def build_pipeline(self, gain=65, reverb=30, noise_reduction=40, mic_range=50):
        src = get_mic_src()

        # gain: volume element 0.0 - 2.0
        gain_val = (gain / 100.0) * 2.0

        # noise reduction via rnnoise (requires gst-plugin-rs with rnnoise)
        # fallback: noisegate
        noise_element = ""
        if noise_reduction > 0:
            threshold = -60 + (noise_reduction / 100.0) * 50  # -60dB to -10dB
            noise_element = f"noisegate threshold={threshold:.1f} ! "

        pipeline_str = (
            f"{src} ! audioconvert ! audioresample ! "
            f"volume volume={gain_val:.2f} ! "
            f"{noise_element}"
            f"pulsesink"  # output to PulseAudio/PipeWire virtual sink
        )

        return pipeline_str

    def start(self, gain=65, reverb=30, noise_reduction=40, mic_range=50):
        self.stop()
        pipeline_str = self.build_pipeline(gain, reverb, noise_reduction, mic_range)
        try:
            self.pipeline = Gst.parse_launch(pipeline_str)
            self.pipeline.set_state(Gst.State.PLAYING)
            self.running = True
        except Exception as e:
            print(f"[Canela] Mic pipeline error: {e}", file=sys.stderr)

    def stop(self):
        if self.pipeline:
            self.pipeline.set_state(Gst.State.NULL)
            self.pipeline = None
        self.running = False

    def update(self, **kwargs):
        if self.running:
            self.start(**kwargs)


# ---------------------------------------------------------------------------
# Main — IPC via stdin/stdout JSON messages
# Called by applet.js as a subprocess
# ---------------------------------------------------------------------------

def main():
    cam = CameraBackend()
    mic = MicBackend()
    loop = GLib.MainLoop()

    def handle_message(message):
        try:
            msg = json.loads(message)
            action = msg.get("action")

            if action == "cam_start":
                cam.start(
                    brightness=msg.get("brightness", 72),
                    contrast=msg.get("contrast", 45),
                    blur=msg.get("blur", 20)
                )
            elif action == "cam_stop":
                cam.stop()
            elif action == "cam_update":
                cam.update(
                    brightness=msg.get("brightness", 72),
                    contrast=msg.get("contrast", 45),
                    blur=msg.get("blur", 20)
                )
            elif action == "mic_start":
                mic.start(
                    gain=msg.get("gain", 65),
                    reverb=msg.get("reverb", 30),
                    noise_reduction=msg.get("noise_reduction", 40),
                    mic_range=msg.get("mic_range", 50)
                )
            elif action == "mic_stop":
                mic.stop()
            elif action == "mic_update":
                mic.update(
                    gain=msg.get("gain", 65),
                    reverb=msg.get("reverb", 30),
                    noise_reduction=msg.get("noise_reduction", 40),
                    mic_range=msg.get("mic_range", 50)
                )
            elif action == "quit":
                cam.stop()
                mic.stop()
                loop.quit()

            # Report back session type on any message
            response = {"session": SESSION, "status": "ok", "action": action}
            print(json.dumps(response), flush=True)

        except Exception as e:
            print(json.dumps({"status": "error", "message": str(e)}), flush=True)

    def on_stdin(source, condition):
        line = source.readline()
        if line:
            handle_message(line.strip())
            return True
        return False

    GLib.io_add_watch(sys.stdin, GLib.IOCondition.IN, on_stdin)
    signal.signal(signal.SIGTERM, lambda *_: loop.quit())

    print(json.dumps({"status": "ready", "session": SESSION}), flush=True)
    loop.run()


if __name__ == "__main__":
    main()
